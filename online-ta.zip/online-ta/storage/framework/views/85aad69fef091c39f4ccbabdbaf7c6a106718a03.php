<?php $__env->startSection('content'); ?>

  

<h1 style="text-align: center; padding: 15px;">ALL TEACHERS LIST ARE HERE</h1>


    <table class="table table-striped display" id="datatable">
      <thead>
        <tr>
          <th scope="col">Varsity ID</th>
          <th scope="col">Full Name</th>
          <th scope="col">Email</th>
          <th scope="col">Department</th>
          <th scope="col">Phone</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>

        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacherInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
          <td><?php echo e($teacherInfo->varsity_id); ?></td>
          <td><?php echo e($teacherInfo->full_name); ?></td>
          <td><?php echo e($teacherInfo->email); ?></td>
          <td><?php echo e($teacherInfo->department); ?></td>
          <td><?php echo e($teacherInfo->phone); ?></td>
          
          


          <td>
          <a href="">
            <button class="btn btn-primary" onclick="" data-toggle="modal" data-target="#exampleModal">EDIT</button>
          </a>
          <a href="<?php echo e(URL::to('deleteTeacher/'.$teacherInfo->id)); ?>">
            <button class="btn btn-danger">DELETE</button>
          </a>
          
        </td>


        </tr>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
      </tbody>
    </table>
            
            
 
      



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins.panel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>